<!--tao nut back to top-->
<div class="fix-footer">
    <a href="javascript:void(0);" title="Top" style="display: inline" class="btn-top">
        <span class="glyphicon glyphicon-arrow-up"></span>
    </a>
</div>
<!--end_tao nut back to top-->
<footer>
    <section class = "col-md-12 footer-head">
        <p>
            <b>Phòng đào tạo trường đại học mỏ địa chất</b><br>
            <b>TRƯỜNG ĐẠI HỌC MỎ ĐỊA CHẤT</b><br>
            Trụ sở: Nhà C12 Tầng, Trường đại học mỏ địa chất- Cổ nhuế - từ liêm - hà nội<br>
            Tel : (84-4)73 036 888– Hotline: (84-9) 0303 3383 <br>
            mail : humg@gmail.com <br>
        </p>
    </section>
    <section class = "col-md-12 footer-end">
        <p>Coppyright &copy; 2013 Huyền Trang</p>
    </section>
</footer>