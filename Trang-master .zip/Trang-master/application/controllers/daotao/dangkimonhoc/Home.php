<?php 
class home extends CI_Controller{
	function index(){
		
	}
}

 ?>