<?php 
include 'header.php';
 ?>
<section class="row">
    <div class="max">
        <div class="col-xs-3" style="border: 1px solid #ccc" >
            <ul style = "list-style: none;">
                <li style = "line-height: 50px">
                    <a href="" style = "display: block">Hệ đào tạo</a>
                </li>
                <li style = "line-height: 50px">
                    <a href="<?php echo base_url()?>daotao/khoa/home" style = "display: block">Quản lí khoa</a>
                </li>
                <li style = "line-height: 50px">
                    <a href="" style = "display: block">Quản lí chuyên ngành</a>
                </li>
            </ul>
        </div>
        <div class="col-xs-8">

        </div>
    </div>
</section>
