<?php 
include 'header.php'

 ?>
 <div class="row"> 
 	<div class="max">
 		<div class="text-center">
 			<h3>Quản lí sinh viên</h3>
 			<form>
 				
 			</form>
 		</div>
 	</div>
 </div>